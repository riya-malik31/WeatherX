import React from "react";
import WeatherApp from "./Components/WeatherApp";
import "./Components/Style.css";
function App() {
  return (
    <>
    <WeatherApp/>
    </>
  );
}

export default App;
